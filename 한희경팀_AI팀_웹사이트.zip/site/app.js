// 한희경팀 AI팀 — 인터랙션 로직
(function () {
  const grid = document.getElementById('teamGrid');
  const overlay = document.getElementById('modalOverlay');
  const modal = document.getElementById('modal');
  const modalContent = document.getElementById('modalContent');
  const modalClose = document.getElementById('modalClose');
  const searchBox = document.getElementById('searchBox');
  const toast = document.getElementById('toast');

  // Stat counters
  document.getElementById('memberCount').textContent = TEAM_DATA.length;
  document.getElementById('promptCount').textContent = TEAM_DATA.reduce((sum, m) => sum + m.prompts.length, 0);

  // ── Render cards ──────────────────────────────
  function renderCards() {
    grid.innerHTML = TEAM_DATA.map(m => `
      <button class="member-card" data-id="${m.id}" data-search="${(m.name + ' ' + m.role + ' ' + m.tasks.join(' ')).toLowerCase()}" style="--card-color:${m.color}; --card-bg:${m.bg}">
        <div class="card-top">
          <span class="card-num">${m.num}</span>
          <div>
            <div class="card-name">${m.name}</div>
            <div class="card-role">${m.role}</div>
          </div>
        </div>
        <p class="card-mission">${m.mission}</p>
        <div class="card-tags">
          ${m.tasks.map(t => `<span class="tag">${t}</span>`).join('')}
        </div>
        <span class="card-open">자세히 보기 →</span>
      </button>
    `).join('');

    grid.querySelectorAll('.member-card').forEach(card => {
      card.addEventListener('click', () => openModal(card.dataset.id));
    });
  }

  // ── Modal ─────────────────────────────────────
  function openModal(id) {
    const m = TEAM_DATA.find(x => x.id === id);
    if (!m) return;

    modalContent.innerHTML = `
      <div style="--card-color:${m.color}; --card-bg:${m.bg}">
        <div class="modal-head">
          <div class="modal-avatar" style="background:${m.bg}; color:${m.color}">${m.num}</div>
          <div>
            <div class="modal-name">${m.name}</div>
            <div class="modal-role">${m.role}</div>
          </div>
        </div>
        <p class="modal-mission" style="border-color:${m.color}">${m.mission}</p>

        <p class="modal-section-label">바로 쓰는 프롬프트</p>
        <div class="prompt-list">
          ${m.prompts.map((p, i) => `
            <div class="prompt-item">
              <div class="prompt-item-head">
                <span class="prompt-item-label">${p.label}</span>
                <button class="copy-btn" data-text="${encodeURIComponent(p.text)}" style="background:${m.color}">복사하기</button>
              </div>
              <div class="prompt-item-text">${p.text}</div>
            </div>
          `).join('')}
        </div>

        <p class="modal-section-label">역할 및 행동 지침</p>
        <div class="guideline-box">${m.guideline}</div>

        <p class="modal-section-label">협업 담당자</p>
        <div class="collab-tags">
          ${m.collab.map(c => `<span class="collab-tag">${c}</span>`).join('')}
        </div>

        <div class="modal-footer-actions">
          <button class="download-btn" id="downloadGuideline">⬇ 이 담당자 지침 다운로드 (.md)</button>
        </div>
      </div>
    `;

    overlay.classList.add('open');
    document.body.style.overflow = 'hidden';

    modalContent.querySelectorAll('.copy-btn').forEach(btn => {
      btn.addEventListener('click', () => copyPrompt(btn));
    });

    document.getElementById('downloadGuideline').addEventListener('click', () => downloadGuideline(m));
  }

  function closeModal() {
    overlay.classList.remove('open');
    document.body.style.overflow = '';
  }

  modalClose.addEventListener('click', closeModal);
  overlay.addEventListener('click', e => { if (e.target === overlay) closeModal(); });
  document.addEventListener('keydown', e => { if (e.key === 'Escape') closeModal(); });

  // ── Copy to clipboard ─────────────────────────
  function copyPrompt(btn) {
    const text = decodeURIComponent(btn.dataset.text);
    const finish = () => {
      btn.textContent = '복사됨 ✓';
      btn.classList.add('copied');
      showToast('프롬프트가 복사되었습니다');
      setTimeout(() => {
        btn.textContent = '복사하기';
        btn.classList.remove('copied');
      }, 1800);
    };
    if (navigator.clipboard && window.isSecureContext) {
      navigator.clipboard.writeText(text).then(finish).catch(() => fallbackCopy(text, finish));
    } else {
      fallbackCopy(text, finish);
    }
  }

  function fallbackCopy(text, cb) {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    try { document.execCommand('copy'); } catch (e) {}
    document.body.removeChild(ta);
    cb();
  }

  function showToast(msg) {
    toast.textContent = msg;
    toast.classList.add('show');
    clearTimeout(showToast._t);
    showToast._t = setTimeout(() => toast.classList.remove('show'), 2200);
  }

  // ── Download single guideline ─────────────────
  function downloadGuideline(m) {
    const content = `# ${m.name} — 역할 및 행동 지침\n\n> ${m.mission}\n\n${m.guideline}\n\n## 바로 쓰는 프롬프트\n\n${m.prompts.map(p => `### ${p.label}\n\`\`\`\n${p.text}\n\`\`\``).join('\n\n')}\n\n## 협업 담당자\n${m.collab.map(c => `- ${c}`).join('\n')}\n`;
    const blob = new Blob([content], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${m.num}_${m.name}.md`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  // ── Search filter ──────────────────────────────
  searchBox.addEventListener('input', () => {
    const q = searchBox.value.trim().toLowerCase();
    document.querySelectorAll('.member-card').forEach(card => {
      const match = !q || card.dataset.search.includes(q);
      card.classList.toggle('hidden', !match);
    });
  });

  renderCards();
})();
